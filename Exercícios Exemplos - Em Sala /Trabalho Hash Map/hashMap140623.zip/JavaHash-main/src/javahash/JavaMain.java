
package javahash;


public class JavaMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FormSistema form = new FormSistema();
        form.setVisible(true);
    }
    
}
